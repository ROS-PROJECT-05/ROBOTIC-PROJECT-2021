void mmal_util(void) {
}
